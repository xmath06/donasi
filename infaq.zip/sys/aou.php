<?php
$rekening=$_POST['rekening'];
$nama=$_POST['nama'];
$takmir=$_POST['takmir'];
$alamat=$_POST['alamat'];
$tipe=$_POST['type'];
$lat=$_POST['lat'];
$lng=$_POST['long'];
$view=$_POST['view'];
$id=$_POST['id'];
$nominal=$_POST['nominal'];
//gambar
$nama_file = $_FILES['gambar']['name'];
$ukuran_file = $_FILES['gambar']['size'];
$tipe_file = $_FILES['gambar']['type'];
$tmp_file = $_FILES['gambar']['tmp_name'];
$file = str_replace(" ","",$nama_file);
$path = "pictures/".$file;

$url = '../admin.php?q=show.php';

require_once 'db_connect.php';
if($nama_file){
    if(move_uploaded_file($tmp_file, $path)){
        if($view==0){
            $sql = "INSERT INTO baitullah (rekening, takmir, nama, alamat, lat, lng, gambar, tipe,nominal) VALUES ('$rekening', '$takmir', '$nama', '$alamat', '$lat', '$lng', '$file', '$tipe', '$nominal')";
            $query = $connect->query($sql);
            if($query === TRUE) {			
                header("location:".$url."&view=".$view."&s=1");	
            } else {		
                header("location:".$url."&view=".$view."&s=3&c=".$sql);
            }
        }else{
            $sql = "UPDATE baitullah SET nama = '$nama', takmir='$takmir', rekening = '$rekening', alamat = '$alamat', tipe = '$tipe', lng='$lng', lat='$lat', gambar='$path' WHERE rekening = '$rekening'"; 
            $query = $connect->query($sql);
            if($query === TRUE) {			
                header("location:".$url."&view=".$view."&s=2&t=5&id=".$id);		
            } else {		
                header("location:".$url."&view=".$view."&s=4&t=5&id=".$id);
            }
        }
    }else{
        header("location:".$url."&view=".$view."&s=6".$path);
    }
}else{
    header("location:".$url."&view=".$view."&s=5&id=".$id);
}
?>