<?php
session_start();
$nohp=$_SESSION['nohp'];
$rekening=$_POST['view'];
$resi=$_POST['resi'];
//gambar
$nama_file = $_FILES['bukti']['name'];
$ukuran_file = $_FILES['bukti']['size'];
$tipe_file = $_FILES['bukti']['type'];
$tmp_file = $_FILES['bukti']['tmp_name'];
$file = str_replace(" ","",$nama_file);
$path = "pictures/".$file;

$url = '../index.php?q=confirm.php';

require_once 'db_connect.php';

if(move_uploaded_file($tmp_file, $path)){
    $sql = "INSERT INTO transaksi (rekening, nohp, resi, bukti) VALUES ('$rekening', '$nohp', '$resi', '$file')";
    $query = $connect->query($sql);
    if($query === TRUE) {			
        header("location:".$url."&view=".$view."&s=1");	
    } else {		
        header("location:".$url."&view=".$view."&s=3&c=".$sql);
    }
}else{
    header("location:".$url."&view=".$view."&s=6".$path);
    }
?>