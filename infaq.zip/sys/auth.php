<?php
require_once "db_connect.php";
$nohp=$_POST['nohp'];
$pass=$_POST['pass'];
$sql = "select * from user WHERE nohp = '$nohp' AND pass = '$pass'";
$query = $connect->query($sql);
$row=$query->fetch_assoc();
if ($row) {
session_start(); // memulai fungsi session
$_SESSION['level'] = $row['level'];
$_SESSION['nohp'] = $row['nohp'];
header("location:../admin.php"); // jika berhasil login, maka masuk ke file home.php
}
else {
header("location:../login.php?s=1&m=".$sql); // jika gagal, maka muncul teks gagal masuk
}
?>