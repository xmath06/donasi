<?php
require_once "db_connect.php";
$id=$_GET['r'];
$url = '../admin.php?q=transaksi.php';
$sql = "UPDATE transaksi SET aprove = 'Y' WHERE resi = '$id'";
$query = $connect->query($sql);
if($query === TRUE) {
    // $sql2= "SELECT * FROM hasil WHERE resi='$id'";
    // require_once "sys/Mesabot.php";
    
    // define("MESABOT_TOKEN","your token");
    
    
    // try {
    
    //     // 1 phone number
    //     $data = [
    //         'destination' => 'phone_number1',
    //         'text' => 'test mesabot'
    //     ];
    
    //     // boradcast
    //     $data = [
    //         'destination' => ['phone_number1','phone_number2'],
    //         'text' => 'test'
    //     ];
    
    //     $mesabot = new Mesabot();
    //     $mesabot->sms($data);
    //     print_r($mesabot->response());
    // } catch (Exception $e) {
    //     echo $e->getMessage();
    // }
	header("location:".$url);
}