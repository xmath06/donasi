<?php
require_once "db_connect.php";
$id=$_GET['id'];
$url = '../admin.php?q=main.php';
$sql = "DELETE FROM baitullah WHERE rekening = {$id}";
$query = $connect->query($sql);
if($query === TRUE) {
	header("location:".$url."&s=1&t=1");
} else {
	header("location:".$url."&s=2&t=1");
}
