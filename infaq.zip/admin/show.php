<?php
$view=$_GET['view'];
$s=$_GET['s'];
// $c=$_GET['c'];
switch($s){
    case 1:
        $alert="info";
        $message="Data berhasil disimpan.";
        break;
    case 2:
        $alert="info";
        $message="Data berhasil diupdate.";
        break;
    case 3:
        $alert="danger";
        $message="Data gagal disimpan.";
        break;
    case 4:
        $alert="danger";
        $message="Data gagal diupdate.";
        break;
    case 5:
        $alert="danger";
        $message="Gambar gagal disimpan.";
        break;
    case 6:
        $alert="danger";
        $message="Upload Gambar gagal disimpan.";
        break;
}
if($view==1){
    require_once 'sys/db_connect.php';
    $id=$_GET['id'];
    
    $sql="SELECT * FROM baitullah WHERE rekening='$id'";
    $query = $connect->query($sql);
    while($row=$query->fetch_assoc()){
    $nama=$row['nama'];
    $rekening=$row['rekening'];
    $alamat=$row['alamat'];
    $tipe=$row['tipe'];
    $lat=$row['lat'];
    $lng=$row['lng'];
    $gambar=$row['gambar'];
    $nominal=$row['nominal'];
    }
} else {
    $view=0;
    $nama="";
    $rekening="";
    $alamat="";
    $tipe="";
    $lat="";
    $lng="";
    $gambar="";
    $nominal="";
}
?>
<form class="form-horizontal" enctype="multipart/form-data" action="sys/aou.php" method="post" id="createMemberForm">

      <div class="modal-body">
      <?php if ($s){
      echo "<div class='alert alert-".$alert." alert-dismissible'>";
        echo "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>";
                echo "<h4><i class='icon fa fa-info'></i> Alert!</h4>";
                echo $message.$c."</div>"; } ?>

		  <div class="form-group"> <!--/here teh addclass has-error will appear -->
		    <label for="nama" class="col-sm-2 control-label">Nama</label>
		    <div class="col-sm-10"> 
		      <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Masjid" value="<?php echo $nama;?>">
			<!-- here the text will apper  -->
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="alamat" class="col-sm-2 control-label">Alamat</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat" value="<?php echo $alamat;?>">
		    </div>
		  </div>
          <div class="form-group">
		    <label for="takmir" class="col-sm-2 control-label">No. HP</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="takmir" name="takmir" placeholder="Nomer HP yang dapat dihubungi" value="<?php echo $alamat;?>">
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="rekening" class="col-sm-2 control-label">Rekening</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="rekening" name="rekening" placeholder="Rekening" value="<?php echo $rekening;?>">
		    </div>
			</div>
            <div class="form-group">
		    <label for="rekening" class="col-sm-2 control-label">Tagihan</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="nominal" name="nominal" placeholder="Tagihan" value="<?php echo $nominal;?>">
		    </div>
			</div>
			<div class="form-group">
			    <label for="type" class="col-sm-2 control-label">Tipe</label>
			    <div class="col-sm-10">
			      <select class="form-control" name="type" id="type">
			      	<option value="">~PILIH~</option>
			      	<option value="pra"<?php if($tipe=="pra"){echo " selected";};?>>Prabayar</option>
			      	<option value="pasca"<?php if($tipe=="pasca"){echo " selected";};?>>Pascabayar</option>
			      </select>
			    </div>
			</div>
			<div class="form-group">
		    <label for="lat" class="col-sm-2 control-label">Latitude</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="lat" name="lat" placeholder="Latitude" value="<?php echo $lat;?>">
		    </div>
			</div>
			<div class="form-group">
		    <label for="long" class="col-sm-2 control-label">Longitude</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="long" name="long" placeholder="Longitude" value="<?php echo $lng;?>">
		    </div>
			</div>
			<div class="form-group">
		    <label for="gambar" class="col-sm-2 control-label">Gambar</label>
		    <div class="col-sm-10">
		      <input type="file" class="form-control" id="gambar" name="gambar">
		    </div>
			</div>	
		  	<input type="hidden" name="view" value="<?php echo $view; ?>"></input>	 		
            <input type="hidden" name="id" value="<?php echo $id; ?>"></input>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>