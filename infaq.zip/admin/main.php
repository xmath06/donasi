<?php
require_once "sys/db_connect.php";
$cari=$_GET['table_search'];
$s=$_GET['s'];
switch($s){
    case 1:
        $alert="info";
        $message="Data berhasil dihapus.";
        break;
    case 2:
        $alert="danger";
        $message="Data gagal dihapus.";
        break;
}
$sql = "SELECT * FROM baitullah WHERE nama LIKE '%$cari%' or rekening LIKE '%$cari%' or alamat LIKE '%$cari%'";
$query = $connect->query($sql);

if ($s){
    echo "<div class='alert alert-".$alert." alert-dismissible'>";
    echo "<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button>";
            echo "<h4><i class='icon fa fa-info'></i> Alert!</h4>";
            echo $message."</div>"; 
            } ?>
<!-- <div class="col-xs-12"> -->
<div class="box">
<div class="box-header">
    <!-- <h3 class="box-title">Responsive Hover Table</h3> -->
    
    <div class="box-tools">
    <form action="" method="get">
        <div class="input-group input-group-sm" style="width: 150px;">
            <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">
            <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
            </div>
        </div>
    </form>
    </div>
</div>
<br />
<table class="table table-hover">
    <tr>
        <th>No.</th>
        <th>Nama masjid</th>
        <th>Rekening</th>
        <th>Tipe</th>
        <th>Alamat</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Gambar</th>
        <th>Option</th>
    </tr>
    <?php
    $i=1;
    while($row=$query->fetch_assoc()){
        echo "<tr><td>".$i.".</td>";
        echo "<td>".$row['nama']."</td>";
        echo "<td>".$row['rekening']."</td>";
        echo "<td>".$row['tipe']."</td>";
        echo "<td>".$row['alamat']."</td>";
        echo "<td>".$row['lat']."</td>";
        echo "<td>".$row['lng']."</td>";
        echo "<td><img src=/sys/pictures/".$row['gambar']."></td>";
        echo "<td><div class='btn-group'><button type='button' class='btn btn-default dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>         Action <span class='caret'></span>       </button>        <ul class='dropdown-menu'>         <li><a type='button' data-toggle='modal' href='?q=show.php&view=1&t=5&id=".$row['rekening']."'> <span class='glyphicon glyphicon-edit'></span> Edit</a></li>";?>
        <li><a type="button" data-toggle="modal" href="sys/hapus.php?id=<?php echo $row['rekening']; ?>" onclick="return confirm('apakah anda yakin ingin menghapus')"> <span class="glyphicon glyphicon-trash"></span> Remove</a></li></td><?php
        $i++;
    }
    ?>

</table>
 <!-- /.box-body -->
 <!-- <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">&laquo;</a></li>
                <li><a href="#" dissabled>1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">&raquo;</a></li>
              </ul>
            </div> -->
        </div>
