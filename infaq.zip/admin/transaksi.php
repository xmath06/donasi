<?php
require_once "sys/db_connect.php";
$cari=$_GET['trans'];
$aprove=$_GET['a'];
if(!$aprove){$aprove="N";};
$sql = "SELECT * FROM hasil WHERE (nama LIKE '%$cari%' or rekening LIKE '%$cari%' or resi LIKE '%$cari%') and aprove='$aprove'";
$query = $connect->query($sql);

?>
<!-- <div class="col-xs-12"> -->
<div class="box">
<div class="box-header">
    <!-- <h3 class="box-title">Responsive Hover Table</h3> -->
    
    <div class="box-tools">
    <form action="" method="get">
        <div class="input-group input-group-sm" style="width: 150px;">
            
            <input type="text" name="trans" class="form-control pull-right" placeholder="Search">

            <div class="input-group-btn">
            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
            </div>
            
        </div>
    </form>
    </div>
</div>
<br />
<table class="table table-hover">
    <tr>
        <th>No.</th>
        <th>Nama masjid</th>
        <th>Dermawan</th>
        <th>Resi</th>
        <th>Bukti</th>
        <th>Tipe</th>
        <th>Status</th>
        
    </tr>
    <?php
    $i=1;
    while($row=$query->fetch_assoc()){
        echo "<tr><td>".$i.".</td>";
        echo "<td>".$row['nama']."</td>";
        echo "<td>".$row['nohp']."</td>";
        echo "<td>".$row['resi']."</td>";
        echo "<td><img src=/sys/bukti/".$row['gambar']."></td>";
        echo "<td>".$row['tipe']."</td>";
        if($aprove=="N"){
        echo "<td><a type='button' class='btn btn-block btn-info btn-sm' href='sys/aprove.php?r=".$row['resi']."'>Setujui</button></td>";
        }else{
            echo "<td>Telah disetujui</td>";
        }
        $i++;
    }
    ?>
</table>