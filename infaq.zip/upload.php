<?php
require_once "sys/db_connect.php";
$rekening=$_GET['id'];
$sql = "SELECT * FROM baitullah WHERE rekening='$rekening'";
$query = $connect->query($sql);
while($row=$query->fetch_assoc()){
    $nama=$row['nama'];
    $rekening=$row['rekening'];
    $alamat=$row['alamat'];
    $tipe=$row['tipe'];
    $lat=$row['lat'];
    $lng=$row['lng'];
    $gambar=$row['gambar'];
    $nominal=$row['nominal'];
    }
?>
<form class="form-horizontal" enctype="multipart/form-data" action="sys/confirm.php" method="post" id="createMemberForm">

      <div class="modal-body">
      	  <div class="form-group"> <!--/here teh addclass has-error will appear -->
		    <label for="nama" class="col-sm-2 control-label">Nama</label>
		    <div class="col-sm-10"> 
		      <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Masjid" value="<?php echo $nama;?>" disabled>
			<!-- here the text will apper  -->
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="alamat" class="col-sm-2 control-label">Alamat</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat" value="<?php echo $alamat;?>" disabled>
		    </div>
		  </div>
          <div class="form-group">
		    <label for="takmir" class="col-sm-2 control-label">No. HP</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="takmir" name="takmir" placeholder="Nomer HP yang dapat dihubungi" value="<?php echo $nohp;?>" disabled>
		    </div>
		  </div>
		  <div class="form-group">
		    <label for="rekening" class="col-sm-2 control-label">Rekening</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="rekening" name="rekening" placeholder="Rekening" value="<?php echo $rekening;?>" disabled>
		    </div>
			</div>
            <div class="form-group">
		    <label for="rekening" class="col-sm-2 control-label">Tagihan</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="nominal" name="nominal" placeholder="Tagihan" value="<?php echo $nominal;?>" disabled>
		    </div>
			</div>
			<div class="form-group">
		    <label for="lat" class="col-sm-2 control-label">Tipe Listrik</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="tipe" name="tipe" placeholder="Tipe Listrik" value="<?php echo $tipe."bayar";?>" disabled>
		    </div>
			</div>
			<div class="form-group">
		    <label for="long" class="col-sm-2 control-label">Token/Resi</label>
		    <div class="col-sm-10">
		      <input type="text" class="form-control" id="resi" name="resi" placeholder="Resi/Token" >
		    </div>
			</div>
			<div class="form-group">
		    <label for="gambar" class="col-sm-2 control-label">Bukti</label>
		    <div class="col-sm-10">
		      <input type="file" class="form-control" id="bukti" name="bukti">
		    </div>
            </div>
            <input type="hidden" name="view" value="<?php echo $rekening; ?>"></input>	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>