<?php
require_once "sys/db_connect.php";
$cari=$_GET['table_search'];
$sql = "SELECT * FROM baitullah WHERE nama LIKE '%$cari%' or rekening LIKE '%$cari%' or alamat LIKE '%$cari%'";
$query = $connect->query($sql);
?>
<form action="" method="get">
<div class="input-group input-group-sm" style="width: 150px;">
    <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">
    <div class="input-group-btn">
        <button type="submit" class="btn btn-default"><i class="fa fa-search">Cari</i></button>
    </div>
</div>
</form>

<section class="tiles">
  <?php
  while($row=$query->fetch_assoc()){?>
    <article class="style1">
      <span class="image">
        <img src="<?php echo "sys/pictures/".$row['gambar'];?>" alt="" />
      </span>
      <a href="?q=get.php&id=<?php echo $row['rekening'];?>">
        <h2><?php echo $row['nama'];?></h2>
        <div class="content">
          <p><?php echo $row['alamat'];?></p>
        </div>
      </a>
    </article>
  <?php } ?>
</section>
