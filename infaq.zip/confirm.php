<?php
require_once "sys/db_connect.php";
$c=$_GET['c'];
$cari=$_POST['table_search'];
$sql = "SELECT * FROM baitullah WHERE nama LIKE '%$cari%' or rekening LIKE '%$cari%' or alamat LIKE '%$cari%'";
$query = $connect->query($sql);

?>
<!-- <div class="col-xs-12"> -->
<div class="box">
<div class="box-header">
    <!-- <h3 class="box-title">Responsive Hover Table</h3> -->
    
    <div class="box-tools">
    <form action="" method="post">
        <div class="input-group input-group-sm" style="width: 150px;">
            <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">
            <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search">Cari</i></button>
            </div>
        </div>
    </form>
    </div>
</div>
<br /><?php echo $c ?>
<table class="table table-hover">
    <tr>
        <th>No.</th>
        <th>Nama masjid</th>
        <th>Rekening</th>
        <th>Tipe</th>
        <th>Alamat</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Gambar</th>
        <th>Option</th>
    </tr>
    <?php
    $i=1;
    while($row=$query->fetch_assoc()){
        echo "<tr><td>".$i.".</td>";
        echo "<td>".$row['nama']."</td>";
        echo "<td>".$row['rekening']."</td>";
        echo "<td>".$row['tipe']."</td>";
        echo "<td>".$row['alamat']."</td>";
        echo "<td>".$row['lat']."</td>";
        echo "<td>".$row['lng']."</td>";
        echo "<td><img src=/sys/pictures/".$row['gambar']."></td>";
        // echo "<td><div class='btn-group'><button type='button' class='btn btn-default dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>         Action <span class='caret'></span>       </button>        <ul class='dropdown-menu'>         <li><a type='button' data-toggle='modal' href='?q=show.php&view=1&t=5&id=".$row['rekening']."'> <span class='glyphicon glyphicon-edit'></span> Edit</a></li>";?>
        <td><a type="button" data-toggle="modal" href="?q=upload.php&id=<?php echo $row['rekening']; ?>">Konfirmasi</a></td></tr><?php
        $i++;
    }
    ?>
</table>
</div>