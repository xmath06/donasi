<?php
require_once "sys/db_connect.php";
$rekening=$_GET['id'];
$sql = "SELECT * FROM baitullah WHERE rekening='$rekening'";
$query = $connect->query($sql);
while($row=$query->fetch_assoc()){

?>
<div>
    <img src="<?php echo "sys/pictures/".$row['gambar']; ?>" width="720px">
    <br />
    <br />
</div>
<div>
    <table>
        <tr>
            <td>Nama</td>
            <td><?php echo $row['nama']; ?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><?php echo $row['alamat']; ?></td>
        </tr>
        <tr>
            <td>Rekening</td>
            <td><?php echo $row['rekening']; ?></td>
        </tr>
        <tr>
            <td>Tipe</td>
            <td><?php echo $row['tipe']."bayar"; ?></td>
        </tr>
        <tr>
            <td>Besar tagihan</td>
            <td><?php echo $row['nominal']; ?></td>
        </tr>
        <tr>
            <td>Peta</td>
            <td><a href="https://www.google.co.id/maps/search/<?php echo $row['lat'].",".$row['lng'] ; ?>">Lokasi</a></td>
        </tr>
</table>
</div>
<div>
    <br />
    <h2>Untuk konfirmasi infaq silahkan login terlebih dahulu</h2>
</div>
<?php } ?>